(function () {
  // Standard loads for CBR (IS 2720-16 / ASTM D1883): 13.24 kN @ 2.5 mm, 19.96 kN @ 5.0 mm
  var STD = { p25: 13.24, p50: 19.96 };
  var PENS = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 7.5, 10.0, 12.5];
  var state = { cbr25: null, cbr50: null, design: null, cbrRun: false };

  var $ = function (id) { return document.getElementById(id); };
  function num(id) {
    var v = $(id).value;
    if (v === "" || v === null) return null;
    var n = parseFloat(v);
    return isFinite(n) ? n : null;
  }
  function fmt(n, d) { return (Math.round(n * Math.pow(10, d)) / Math.pow(10, d)).toFixed(d); }

  // Build load table
  var tbody = document.querySelector("#loadTable tbody");
  PENS.forEach(function (p, i) {
    var tr = document.createElement("tr");
    var key = (p === 2.5 || p === 5.0);
    if (key) tr.className = "key";
    tr.innerHTML = '<td>' + p.toFixed(1) + (key ? ' *' : '') + '</td>' +
      '<td><input type="number" step="any" min="0" inputmode="decimal" id="ld' + i + '" aria-label="Load at ' + p + ' mm"></td>';
    tbody.appendChild(tr);
  });

  function ratingFor(c) {
    if (c < 3) return "Very poor";
    if (c < 5) return "Poor";
    if (c < 10) return "Fair";
    if (c < 20) return "Good";
    if (c < 30) return "Very good";
    return "Excellent (granular)";
  }

  function getLoads() {
    return PENS.map(function (p, i) { return num("ld" + i); });
  }

  function calcCBR() {
    var loads = getLoads();
    var l25 = loads[PENS.indexOf(2.5)], l50 = loads[PENS.indexOf(5.0)];
    var out = $("cbrOut");
    $("cbrCard").classList.remove("hidden");
    if (l25 === null || l50 === null || l25 <= 0 || l50 <= 0) {
      out.innerHTML = '<p><strong>Please enter positive loads at both 2.5 mm and 5.0 mm penetration.</strong></p>';
      $("adoptRow").classList.add("hidden");
      $("chartBox").innerHTML = "";
      state.cbrRun = false;
      return;
    }
    var c25 = l25 / STD.p25 * 100;
    var c50 = l50 / STD.p50 * 100;
    state.cbr25 = c25; state.cbr50 = c50; state.cbrRun = true;

    var higher50 = c50 > c25;
    $("adoptRow").classList.toggle("hidden", !higher50);
    if (!higher50) $("adopt50").checked = false;

    var design = (higher50 && $("adopt50").checked) ? c50 : c25;
    state.design = design;
    var cond = $("condition").value === "soaked" ? "soaked" : "unsoaked";

    var html = '';
    html += '<div class="result-big">Design CBR = ' + fmt(design, 1) + ' %</div>';
    html += '<span class="pill">' + ratingFor(design) + ' subgrade</span> <span class="pill">' + cond + '</span>';
    html += '<ul>';
    html += '<li>CBR at 2.5 mm = ' + fmt(l25, 2) + ' / ' + STD.p25 + ' × 100 = <strong>' + fmt(c25, 1) + ' %</strong></li>';
    html += '<li>CBR at 5.0 mm = ' + fmt(l50, 2) + ' / ' + STD.p50 + ' × 100 = <strong>' + fmt(c50, 1) + ' %</strong></li>';
    html += '</ul>';
    if (higher50) {
      html += '<p class="note"><strong>Note:</strong> the 5.0 mm CBR is higher than the 2.5 mm CBR. Standards require the test to be repeated; if the same result is obtained, adopt the 5.0 mm value (tick the box above). Until then the 2.5 mm value is used.</p>';
    }
    if ($("condition").value === "unsoaked") {
      html += '<p class="note">Unsoaked CBR can overestimate strength. Pavement design normally uses the soaked CBR at the expected moisture condition.</p>';
    }
    out.innerHTML = html;
    drawChart(loads);
  }

  function drawChart(loads) {
    var pts = [];
    PENS.forEach(function (p, i) { if (loads[i] !== null) pts.push([p, loads[i]]); });
    if (pts.length < 2) { $("chartBox").innerHTML = ""; return; }
    var W = 520, H = 300, L = 50, R = 14, T = 16, B = 42;
    var maxX = 12.5;
    var maxY = Math.max(STD.p50 * 1.1, Math.max.apply(null, pts.map(function (q) { return q[1]; })) * 1.1);
    function X(v) { return L + (v / maxX) * (W - L - R); }
    function Y(v) { return H - B - (v / maxY) * (H - T - B); }
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Load versus penetration curve">';
    // grid + axes
    var xt = [0, 2.5, 5, 7.5, 10, 12.5];
    xt.forEach(function (v) {
      s += '<line x1="' + X(v) + '" y1="' + T + '" x2="' + X(v) + '" y2="' + (H - B) + '" stroke="#1b5e20" stroke-opacity=".25"/>';
      s += '<text x="' + X(v) + '" y="' + (H - B + 16) + '" font-size="12" text-anchor="middle">' + v + '</text>';
    });
    var step = maxY > 40 ? 10 : (maxY > 20 ? 5 : 2);
    for (var yv = 0; yv <= maxY; yv += step) {
      s += '<line x1="' + L + '" y1="' + Y(yv) + '" x2="' + (W - R) + '" y2="' + Y(yv) + '" stroke="#1b5e20" stroke-opacity=".25"/>';
      s += '<text x="' + (L - 6) + '" y="' + (Y(yv) + 4) + '" font-size="12" text-anchor="end">' + yv + '</text>';
    }
    s += '<line x1="' + L + '" y1="' + (H - B) + '" x2="' + (W - R) + '" y2="' + (H - B) + '" stroke="#000" stroke-width="2"/>';
    s += '<line x1="' + L + '" y1="' + T + '" x2="' + L + '" y2="' + (H - B) + '" stroke="#000" stroke-width="2"/>';
    s += '<text x="' + ((L + W - R) / 2) + '" y="' + (H - 6) + '" font-size="13" text-anchor="middle">Penetration (mm)</text>';
    s += '<text x="14" y="' + ((T + H - B) / 2) + '" font-size="13" text-anchor="middle" transform="rotate(-90 14 ' + ((T + H - B) / 2) + ')">Load (kN)</text>';
    // standard load markers
    s += '<circle cx="' + X(2.5) + '" cy="' + Y(STD.p25) + '" r="5" fill="none" stroke="#000" stroke-width="2"/>';
    s += '<circle cx="' + X(5) + '" cy="' + Y(STD.p50) + '" r="5" fill="none" stroke="#000" stroke-width="2"/>';
    s += '<text x="' + (X(2.5) + 8) + '" y="' + (Y(STD.p25) - 6) + '" font-size="11">std 13.24</text>';
    s += '<text x="' + (X(5) + 8) + '" y="' + (Y(STD.p50) - 6) + '" font-size="11">std 19.96</text>';
    // curve
    var d = pts.map(function (q, i) { return (i ? "L" : "M") + X(q[0]) + " " + Y(q[1]); }).join(" ");
    s += '<path d="' + d + '" fill="none" stroke="#000" stroke-width="2.5"/>';
    pts.forEach(function (q) { s += '<circle cx="' + X(q[0]) + '" cy="' + Y(q[1]) + '" r="3.5" fill="#000"/>'; });
    s += '</svg><p class="note">Solid line: your test curve. Open circles: standard loads for 100 % CBR.</p>';
    $("chartBox").innerHTML = s;
  }

  // Suitability rules. cbr: [pass minimum, marginal minimum]
  var RULES = {
    subgrade:   { name: "Road subgrade",     cbr: [5, 3],   ll: 50, pi: 25, swell: 1.5, comp: 95,  org: 2 },
    subbase:    { name: "Sub-base course",   cbr: [30, 20], ll: 35, pi: 12, swell: 1.0, comp: 98,  org: 1 },
    base:       { name: "Base course",       cbr: [80, 60], ll: 30, pi: 6,  swell: 0.5, comp: 100, org: 1 },
    embankment: { name: "Embankment / fill", cbr: [5, 3],   ll: 60, pi: 30, swell: 2.0, comp: 95,  org: 3 },
    foundation: { name: "Shallow foundation",cbr: [10, 5],  ll: 50, pi: 25, swell: 1.5, comp: 95,  org: 2 }
  };

  function checkSuitability() {
    var key = $("structure").value;
    var r = RULES[key];
    var checks = [];
    function add(status, title, detail) { checks.push({ s: status, t: title, d: detail }); }

    // CBR
    if (state.cbrRun && state.design !== null) {
      var c = state.design;
      if (c >= r.cbr[0]) add("PASS", "CBR", fmt(c, 1) + " % meets the minimum of " + r.cbr[0] + " % for " + r.name.toLowerCase() + ".");
      else if (c >= r.cbr[1]) add("WARN", "CBR", fmt(c, 1) + " % is marginal (minimum " + r.cbr[0] + " %). Improvement or a thicker design may be needed.");
      else add("FAIL", "CBR", fmt(c, 1) + " % is below the acceptable range (minimum " + r.cbr[0] + " %).");
    } else {
      add("WARN", "CBR", "Not calculated yet. Run Step 1 first for a complete assessment.");
    }

    var ll = num("ll"), pi = num("pi"), sw = num("swell"), cp = num("comp"), og = num("organic");
    if (ll !== null) ll <= r.ll ? add("PASS", "Liquid limit", ll + " % ≤ " + r.ll + " %.") : add("FAIL", "Liquid limit", ll + " % exceeds " + r.ll + " %.");
    if (pi !== null) {
      if (pi <= r.pi) add("PASS", "Plasticity index", pi + " % ≤ " + r.pi + " %.");
      else if (pi <= r.pi * 1.25) add("WARN", "Plasticity index", pi + " % is slightly above " + r.pi + " %. Consider lime/cement modification.");
      else add("FAIL", "Plasticity index", pi + " % exceeds " + r.pi + " %.");
    }
    if (sw !== null) sw <= r.swell ? add("PASS", "Swell", sw + " % ≤ " + r.swell + " %.") : add("FAIL", "Swell", sw + " % exceeds " + r.swell + " %. Risk of heave.");
    if (cp !== null) {
      if (cp >= r.comp) add("PASS", "Compaction", cp + " % of MDD meets " + r.comp + " %.");
      else if (cp >= r.comp - 3) add("WARN", "Compaction", cp + " % of MDD is slightly below " + r.comp + " %.");
      else add("FAIL", "Compaction", cp + " % of MDD is well below " + r.comp + " %.");
    }
    if (og !== null) og <= r.org ? add("PASS", "Organic content", og + " % is acceptable.") : add("FAIL", "Organic content", og + " % exceeds " + r.org + " %. Remove or replace organic soil.");

    var st = $("soilType").value;
    if (st === "Pt" || st === "OH" || st === "OL") add("FAIL", "Soil type", st + " soils (organic/peat) are unsuitable without removal or replacement.");
    else if (st === "CH" || st === "MH") add("WARN", "Soil type", st + " is highly plastic: expect high swell/shrink and low strength. Stabilization is advisable.");
    else if (st) add("PASS", "Soil type", st + " is not flagged as problematic on its own.");

    if (key === "foundation") {
      var qa = num("qa"), qd = num("qd"), gw = num("gw");
      if (qa !== null && qd !== null && qd > 0) {
        var f = qa / qd;
        if (f >= 1.2) add("PASS", "Bearing capacity", "Allowable " + qa + " kPa vs applied " + qd + " kPa (ratio " + fmt(f, 2) + ").");
        else if (f >= 1) add("WARN", "Bearing capacity", "Ratio " + fmt(f, 2) + " leaves little margin. Consider a larger footing.");
        else add("FAIL", "Bearing capacity", "Applied pressure " + qd + " kPa exceeds allowable " + qa + " kPa.");
      } else {
        add("WARN", "Bearing capacity", "Enter allowable bearing capacity and applied pressure to check the foundation.");
      }
      if (gw !== null) gw >= 1.5 ? add("PASS", "Water table", gw + " m below founding level.") : add("WARN", "Water table", gw + " m is shallow. Check reduced bearing capacity and drainage.");
    }

    var fails = checks.filter(function (x) { return x.s === "FAIL"; }).length;
    var warns = checks.filter(function (x) { return x.s === "WARN"; }).length;
    var vTitle, vText;
    if (fails > 0) { vTitle = "NOT SUITABLE as-is"; vText = fails + " check(s) failed for " + r.name.toLowerCase() + "."; }
    else if (warns > 0) { vTitle = "MARGINAL: needs improvement or more data"; vText = warns + " item(s) need attention for " + r.name.toLowerCase() + "."; }
    else { vTitle = "SUITABLE"; vText = "All entered checks pass for " + r.name.toLowerCase() + "."; }

    var html = '<div class="verdict"><h3>' + vTitle + '</h3><div>' + vText + '</div></div>';
    checks.forEach(function (c) {
      html += '<div class="check"><span class="tag">' + c.s + '</span><div><strong>' + c.t + '</strong><br>' + c.d + '</div></div>';
    });
    if (fails > 0 || warns > 0) {
      html += '<p><strong>Possible remedies:</strong></p><ul>' +
        '<li>Stabilize with lime (clayey soils) or cement (sandy soils), then re-test the CBR.</li>' +
        '<li>Excavate and replace weak layers with a selected granular material.</li>' +
        '<li>Improve compaction control and drainage; keep moisture near OMC.</li>' +
        (key === "foundation" ? '<li>Increase footing size, deepen the foundation, or consider a raft or piles.</li>' : '<li>Increase the pavement or layer thickness to suit the lower CBR.</li>') +
        '</ul>';
    }
    $("suitOut").innerHTML = html;
    $("suitCard").classList.remove("hidden");
    $("suitCard").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function loadSample() {
    var sample = [1.6, 3.4, 5.3, 7.2, 9.0, 10.5, 12.9, 14.6, 18.2, 21.0, 22.8];
    sample.forEach(function (v, i) { $("ld" + i).value = v; });
    $("ll").value = 38; $("pi").value = 14; $("swell").value = 0.8; $("comp").value = 96; $("organic").value = 0.5;
    $("soilType").value = "SC";
    $("qa").value = 180; $("qd").value = 120; $("gw").value = 2.5;
    calcCBR();
  }

  function resetAll() {
    var inputs = document.querySelectorAll("input[type=number]");
    for (var i = 0; i < inputs.length; i++) inputs[i].value = "";
    $("adopt50").checked = false;
    $("soilType").value = "";
    $("cbrCard").classList.add("hidden");
    $("suitCard").classList.add("hidden");
    state = { cbr25: null, cbr50: null, design: null, cbrRun: false };
  }

  $("calcBtn").addEventListener("click", calcCBR);
  $("adopt50").addEventListener("change", calcCBR);
  $("condition").addEventListener("change", function () { if (state.cbrRun) calcCBR(); });
  $("checkBtn").addEventListener("click", checkSuitability);
  $("sampleBtn").addEventListener("click", loadSample);
  $("resetBtn").addEventListener("click", resetAll);
  $("structure").addEventListener("change", function () {
    $("foundFields").classList.toggle("hidden", $("structure").value !== "foundation");
  });
})();
